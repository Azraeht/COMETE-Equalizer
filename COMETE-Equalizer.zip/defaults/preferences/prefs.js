

// Used to detect the first time the extension is run 
pref("extensions.cometeeq.firstrun", true);

// See http://kb.mozillazine.org/Localize_extension_descriptions
// pref("extensions.{caf68136-085e-402e-a6ce-471d52be6f64}.description", "chrome://cometeeq/locale/cometeeq.properties");
